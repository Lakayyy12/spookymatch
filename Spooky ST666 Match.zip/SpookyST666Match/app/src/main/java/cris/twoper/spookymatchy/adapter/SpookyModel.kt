package cris.twoper.spookymatchy.adapter

data class SpookyModel(
    val title: String
)
